#pragma once

#define _IL2CPP_UNITY
#define _RUST

#include "internal.hpp"
#include "unity.hpp"
