# OmbraLib
Ombra Core Library - Standard Kernel Library
