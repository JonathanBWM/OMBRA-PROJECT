#pragma once

#include "cpp.h"
#include "Setup.hpp"

namespace window {
	void Hide(int hwnd, char* pTeb);
}