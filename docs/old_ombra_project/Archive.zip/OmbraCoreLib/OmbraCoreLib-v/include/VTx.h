#pragma once

#pragma warning (disable:4267)
#pragma warning (disable:4201)
#pragma warning (disable:4334)

#include "macros.h"
#include "data.h"
#include "MemoryEx.h"
#include "VMCSCheck.h"
#include "power.h"
#include "bitmap.h"
#include "VMTimers.h"
#include "VMExitHandlers.h"
#include "winternlex.h"
#include "bugcheck.h"
#include "VMMDef.h"
