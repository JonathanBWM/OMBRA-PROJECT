#pragma once

#define DbgLog(x, ...) (printf(x "\n", __VA_ARGS__))