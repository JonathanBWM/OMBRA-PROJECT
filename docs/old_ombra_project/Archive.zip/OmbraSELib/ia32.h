#pragma once
// OmbraSELib ia32 wrapper
// In vmxroot context, PayLoad has its own ia32.hpp - this header is a no-op

#ifndef _VMXROOT_MODE
#include <ia32.h>
#endif
