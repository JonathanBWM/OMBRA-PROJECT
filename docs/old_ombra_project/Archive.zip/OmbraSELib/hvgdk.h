#pragma once
// OmbraSELib Hyper-V Guest Development Kit wrapper
#include <Arch/Hyper-V.h>
