#pragma once
// OmbraSELib EPT wrapper
// In vmxroot context, EPT functionality is handled differently - this header is a no-op

#ifndef _VMXROOT_MODE
#include <EPT.h>
#endif
